package com.example.pictopz;

public class UserObject {
    public String username;
    public String email;
    public String phone;

    public UserObject()
    {

    }

    public UserObject(String username, String email, String phone) {
        this.username = username;
        this.email = email;
        this.phone = phone;
    }
}
